"use strict";
function woof_init_byrating() {}