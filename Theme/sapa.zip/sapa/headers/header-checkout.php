<header id="tbay-header" class="tbay_header-template site-header header-checkout">
	<div class="container">
		<?php
			/**
			* sapa_theme_header_checkout hook
			*
			* @hooked sapa_the_logo_checkout - 10
			*/
			do_action('sapa_theme_header_checkout');
		?>
	</div>
</header>