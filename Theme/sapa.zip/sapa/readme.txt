=== Sapa ===

Contributors: automattic
Tags: translation-ready, custom-background, theme-options, custom-menu, post-formats, threaded-comments

Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A starter theme called Sapa, or underscores.

== Description ==

Sapa is a flexible and customizable WooCommerce Multi-Store WordPress Theme that installs and changes any item in a matter of minutes via Powerful Theme Options, you can also customize Google fonts. No code is easy and simple.


== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

== Changelog ==

Version 1.0.10 - October 31, 2023
- [FIX] Fix Ajax mega menu error

Version 1.0.9 - October 30, 2023
- Compatible with Elementor 3.17.x
- [FIX] Fix Ajax add to cart error in single product on mobile devices
- [FIX] Fix 'Size Guide' and 'Delivery and Returns' and 'Ask a Question' with spaces on Theme Options still showing

Version 1.0.8 - September 14, 2023
- [ADD NEW] Demo Drone
- Compatible with Elementor 3.16.x
- Compatible with WooCommerce 8.1.x

Version 1.0.7 - September 06, 2023
- [ADD NEW] Demo Bicycle
- Compatible with Elementor 3.15.x
- Compatible with WooCommerce 8.0.x
- Compatible with HUSKY – Products Filter for WooCommerce Professional Version 3.3.4.3+
- [FIX] Fix Ajax wishlist count not working

Version 1.0.6 - August 19, 2023
- [ADD NEW] Demo Shoes

Version 1.0.5 - August 13, 2023
- [ADD NEW] Demo Glasses

Version 1.0.4 - August 07, 2023
- [ADD NEW] Demo glasses

Version 1.0.3 - August 04, 2023
- [ADD NEW] Demo HeadPhone

Version 1.0.2 - July 31, 2023
- [ADD NEW] Demo Smartwatch 4
- [ADD NEW] Demo Dark Mode

Version 1.0.1 - July 28, 2023
- [ADD NEW] Demo Smartwatch 2
- [ADD NEW] Demo Smartwatch 3

Version 1.0.0 - July 26, 2023
- Initial release

== Credits ==

* Based on Underscores http://underscores.me/,(C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/,(C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
