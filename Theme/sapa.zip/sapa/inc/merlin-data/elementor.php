<?php

class Sapa_Merlin_Elementor
{
    public function import_files_demo_default()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/smart-watch-1/revslider/slider-smart-watch-1.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/smart-watch-1/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/smart-watch-1/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo Smart Watch 1',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/smart-watch-1/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/smart-watch-1/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/',
            ),
        );
    }

    public function import_files_demo_2()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/smart-watch-2/revslider/slider-smart-watch-2.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/smart-watch-2/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/smart-watch-2/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo Smart Watch 2',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/smart-watch-2/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/smart-watch-2/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-2/',
            ),
        );
    }

    
    public function import_files_demo_3()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/smart-watch-3/revslider/slider-smart-watch-3.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/smart-watch-3/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/smart-watch-3/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo Smart Watch 3',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/smart-watch-3/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/smart-watch-3/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-3/',
            ),
        );
    }

    
    public function import_files_demo_4()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/smart-watch-4/revslider/slider-smart-watch-4.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/smart-watch-4/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/smart-watch-4/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo Smart Watch 4',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/smart-watch-4/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/smart-watch-4/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-4/',
            ),
        );
    }

    public function import_files_demo_head_phone_1()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/head-phone-1/revslider/slider-head-phone-1.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/head-phone-1/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/head-phone-1/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo HeadPhone 1',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/head-phone-1/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/head-phone-1/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-5/',
            ),
        );
    }

    public function import_files_demo_head_phone_2()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/head-phone-2/revslider/slider-head-phone-2.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/head-phone-2/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/head-phone-2/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo HeadPhone 2',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/head-phone-2/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/head-phone-2/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-6/',
            ),
        );
    }
    

    public function import_files_demo_glasses()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/glasses/revslider/slider-glasses.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/glasses/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/glasses/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo Glasses',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/glasses/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/glasses/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-7/',
            ),
        );
    }
    

    public function import_files_demo_shoes()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/shoes/revslider/slider-shoes.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/shoes/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/shoes/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo Shoes',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/shoes/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/shoes/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-8/',
            ),
        );
    }

    
    public function import_files_demo_bicycle()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/bicycle/revslider/slider-bicycle.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/bicycle/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/bicycle/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo Bicycle',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/bicycle/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/bicycle/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-9/',
            ),
        );
    }
    public function import_files_demo_drone()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/drone/revslider/slider-drone.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/drone/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/drone/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo Drone',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/drone/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/drone/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-10/',
            ),
        );
    }
    
    public function import_files_demo_dark()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/demo-dark/revslider/slider-demo-dark.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/demo-dark/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/demo-dark/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo Dark Mode',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/demo-dark/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/demo-dark/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-dark/',
            ),
        );
    }
    

    public function import_files_demo_rtl()
    {
        $rev_sliders = array(
            "http://demosamples.thembay.com/sapa/demo-rtl/revslider/slider-smart-watch.zip",
        );
    
        $data_url = "http://demosamples.thembay.com/sapa/demo-rtl/data.xml";
        $widget_url = "http://demosamples.thembay.com/sapa/demo-rtl/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo RTL',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "http://demosamples.thembay.com/sapa/demo-rtl/home/redux_options.json",
                        'option_name' => 'sapa_tbay_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "http://demosamples.thembay.com/sapa/demo-rtl/home/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sapa'),
                'preview_url'                => 'https://sapa.thembaydev.com/demo-rtl/',
            ),
        );
    }
}
