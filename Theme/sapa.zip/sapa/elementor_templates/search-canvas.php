<?php 
/**
 * Templates Name: Elementor
 * Widget: Search Canvas
 */
?>
<div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
    <?php $this->render_search_canvas(); ?>
</div>
    