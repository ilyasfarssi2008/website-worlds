<?php
/**
 * Templates Name: Elementor
 * Widget: Custom Language
 */
    
?>
<div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
    <?php $this->sapa_custom_language(); ?>
</div>